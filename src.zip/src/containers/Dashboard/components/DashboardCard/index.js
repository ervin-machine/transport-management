import React from 'react'

function DashboardCard(props) {
  return (
    <div>
        
    </div>
  )
}

export default DashboardCard