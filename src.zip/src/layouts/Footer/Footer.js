import React from 'react'

function Footer() {
  return (
    <div className='footer-head'>© 2022 All rights reserved. Kusur.</div>
  )
}

export default Footer