const Data = {
    SidebarList: [
        {
            title: "Dashboard",
            icon: "",
            subTitle: []
        },
        {
            title: "Loyalty",
            icon: "",
            subTitle: []
        },
        {
            title: "Proizvodi",
            icon: "",
            subTitle: []
        },
        {
            title: "Sadržaji",
            icon: "",
            subTitle: []
        },
        {
            title: "Korisnici aplikacije",
            icon: "",
            subTitle: []
        },
        {
            title: "Notifikacije",
            icon: "",
            subTitle: []
        },
        {
            title: "Anketa",
            icon: "",
            subTitle: []
        },
        {
            title: "Baneri",
            icon: "",
            subTitle: []
        },
        {
            title: "Dokumenti",
            icon: "",
            subTitle: []
        },
        {
            title: "Postavke",
            icon: "",
            subTitle: []
        },
    ]
}

export default Data